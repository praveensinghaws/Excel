VertiPaq Analyzer 2.10
-----------------
Compatible with Excel 2016, can only read VPAX files exported 
using DAX Studio 2.13.1 or higher versions
